const SalesOrder = require('../models/SalesOrder');
const Customer = require('../models/Customer');
const Product = require('../models/Product');
const AppSetting = require('../models/AppSetting');
const ApiError = require('../utils/ApiError');
const { paginate } = require('../helpers');
const { SO_STATUS } = require('../constants');
const inventoryService = require('./inventory.service');
const financeService = require('./finance.service');
const config = require('../config');
const { getMySQLPool } = require('../config/database');
const mongoose = require('mongoose');
const logger = require('../utils/logger');

// ─── Valid status transitions ───
const STATUS_TRANSITIONS = {
  [SO_STATUS.DRAFT]: [SO_STATUS.PACKED, SO_STATUS.CANCELED],
  [SO_STATUS.PACKED]: [SO_STATUS.DELIVERED],
  [SO_STATUS.DELIVERED]: [SO_STATUS.PARTIAL_DELIVERED, SO_STATUS.RETURNED, SO_STATUS.COMPLETED],
  [SO_STATUS.PARTIAL_DELIVERED]: [SO_STATUS.DELIVERED, SO_STATUS.RETURNED, SO_STATUS.COMPLETED],
};

const LEGACY_STATUS_MAP = {
  draft: SO_STATUS.DRAFT,
  confirmed: SO_STATUS.PACKED,
  processing: SO_STATUS.PACKED,
  ready_to_ship: SO_STATUS.PACKED,
  partial_shipped: SO_STATUS.PARTIAL_DELIVERED,
  shipped: SO_STATUS.DELIVERED,
  completed: SO_STATUS.COMPLETED,
  cancelled: SO_STATUS.CANCELED,
};

const normalizeSoStatus = (status) => LEGACY_STATUS_MAP[status] || status;

const normalizeSoItems = (items = []) => items.map((item) => {
  const quantity = Number(item.quantity ?? item.quantityOrdered ?? item.quantityShipped ?? 0);

  return {
    ...item,
    quantity,
  };
});

const ensureSoItemQuantities = (items = []) => {
  for (const item of items) {
    if (!Number.isFinite(item.quantity) || item.quantity < 1) {
      throw ApiError.badRequest('Quantity item SO minimal 1');
    }
  }
};

const toDeliveryLikePayload = (so) => ({
  _id: so._id,
  salesOrderId: so._id,
  customerId: so.customerId,
  deliveryNumber: so.invoiceNumber,
  deliveredAt: so.deliveredAt,
  updatedBy: so.updatedBy,
  items: (so.items || []).map((item) => ({
    productId: item.productId?._id || item.productId,
    satuan: item.satuan,
    quantityOrdered: Number(item.quantity || 0),
    quantityShipped: Number(item.quantity || 0),
    batchNumber: item.batchNumber || null,
    expiryDate: item.expiryDate || null,
  })),
});

/**
 * Get PPN config from settings
 */
const getPpnConfig = async () => {
  const settings = await AppSetting.getSettings();
  const isPkp = settings?.company?.tax?.isPkp || false;
  const ppnRate = isPkp ? (settings?.company?.tax?.defaultPpnRate ?? 11) : 0;
  return { isPkp, ppnRate };
};

/**
 * Get all sales orders
 */
const mongoGetSalesOrders = async (queryParams) => {
  const { page, limit, search, status, customerId, dateFrom, dateTo, sort } = queryParams;

  const filter = {};

  if (search) {
    const escaped = search.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    filter.$or = [
      { invoiceNumber: { $regex: escaped, $options: 'i' } },
      { fakturNumber: { $regex: escaped, $options: 'i' } },
    ];
  }

  if (status) {
    const statuses = status.split(',').map((s) => s.trim());
    filter.status = statuses.length > 1 ? { $in: statuses } : statuses[0];
  }
  if (customerId) filter.customerId = customerId;

  if (dateFrom || dateTo) {
    filter.orderDate = {};
    if (dateFrom) filter.orderDate.$gte = new Date(dateFrom);
    if (dateTo) filter.orderDate.$lte = new Date(dateTo + 'T23:59:59.999Z');
  }

  return paginate(SalesOrder, {
    filter,
    page,
    limit,
    sort: sort || '-createdAt',
    populate: [
      { path: 'customerId', select: 'name code type phone' },
      { path: 'items.productId', select: 'name sku golongan satuan' },
      { path: 'createdBy', select: 'name' },
      { path: 'updatedBy', select: 'name' },
    ],
  });
};

/**
 * Get sales order statistics
 */
const mongoGetStats = async () => {
  const now = new Date();
  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

  const [
    total,
    statusCounts,
    totalValueResult,
    monthlyValueResult,
    topCustomers,
  ] = await Promise.all([
    SalesOrder.countDocuments(),
    SalesOrder.aggregate([
      { $group: { _id: '$status', count: { $sum: 1 } } },
    ]),
    SalesOrder.aggregate([
      { $match: { status: { $nin: [SO_STATUS.CANCELED] } } },
      { $group: { _id: null, total: { $sum: '$totalAmount' } } },
    ]),
    SalesOrder.aggregate([
      { $match: { orderDate: { $gte: startOfMonth }, status: { $nin: [SO_STATUS.CANCELED] } } },
      { $group: { _id: null, total: { $sum: '$totalAmount' } } },
    ]),
    SalesOrder.aggregate([
      { $match: { status: { $nin: [SO_STATUS.CANCELED] } } },
      {
        $group: {
          _id: '$customerId',
          totalOrders: { $sum: 1 },
          totalValue: { $sum: '$totalAmount' },
        },
      },
      { $sort: { totalValue: -1 } },
      { $limit: 5 },
      {
        $lookup: {
          from: 'customers',
          localField: '_id',
          foreignField: '_id',
          as: 'customer',
        },
      },
      { $unwind: '$customer' },
      {
        $project: {
          customerId: '$_id',
          name: '$customer.name',
          totalOrders: 1,
          totalValue: 1,
        },
      },
    ]),
  ]);

  const statusMap = {};
  for (const s of statusCounts) {
    const normalized = normalizeSoStatus(s._id);
    statusMap[normalized] = (statusMap[normalized] || 0) + s.count;
  }

  const totalValue = totalValueResult[0]?.total || 0;
  const totalValueThisMonth = monthlyValueResult[0]?.total || 0;
  const activeTotal = total - (statusMap[SO_STATUS.CANCELED] || 0);

  return {
    total,
    packed: statusMap[SO_STATUS.PACKED] || 0,
    delivered: statusMap[SO_STATUS.DELIVERED] || 0,
    partialDelivered: statusMap[SO_STATUS.PARTIAL_DELIVERED] || 0,
    returned: statusMap[SO_STATUS.RETURNED] || 0,
    canceled: statusMap[SO_STATUS.CANCELED] || 0,
    totalValue,
    totalValueThisMonth,
    averageOrderValue: activeTotal > 0 ? Math.round(totalValue / activeTotal) : 0,
    topCustomers,
  };
};

/**
 * Get sales order by ID
 */
const mongoGetSalesOrderById = async (id) => {
  const so = await SalesOrder.findById(id)
    .populate('customerId', 'name code type phone address izinSarana apoteker sipa creditLimit')
    .populate('items.productId', 'name sku golongan satuan')
    .populate('createdBy', 'name')
    .populate('updatedBy', 'name');

  if (!so) {
    throw ApiError.notFound('Sales order tidak ditemukan');
  }

  return so;
};

/**
 * Create a new sales order
 */
const mongoCreateSalesOrder = async (data, userId) => {
  if (data.fakturNumber === undefined && data.noFaktur !== undefined) {
    data.fakturNumber = data.noFaktur;
  }
  delete data.noFaktur;

  data.items = normalizeSoItems(data.items);
  ensureSoItemQuantities(data.items);

  // Validate customer
  const customer = await Customer.findById(data.customerId);
  if (!customer) {
    throw ApiError.notFound('Customer tidak ditemukan');
  }
  if (!customer.isActive) {
    throw ApiError.badRequest('Customer tidak aktif');
  }

  // Check SIA requirement
  const settings = await AppSetting.getSettings();
  if (settings?.customer?.requireSIA) {
    if (customer.izinSarana?.expiryDate && new Date(customer.izinSarana.expiryDate) < new Date()) {
      throw ApiError.badRequest('Izin Sarana pelanggan sudah expired');
    }
  }

  // Validate all products exist and are active
  const productIds = data.items.map((item) => item.productId);
  const products = await Product.find({ _id: { $in: productIds } });

  if (products.length !== productIds.length) {
    throw ApiError.badRequest('Satu atau lebih produk tidak ditemukan');
  }

  const inactiveProduct = products.find((p) => !p.isActive);
  if (inactiveProduct) {
    throw ApiError.badRequest(`Produk "${inactiveProduct.name}" tidak aktif`);
  }

  // Default shipping address from customer
  if (!data.shippingAddress && customer.address) {
    const addr = customer.address;
    const parts = [addr.street, addr.city, addr.province].filter(Boolean);
    data.shippingAddress = parts.join(', ');
  }

  // Default payment term from settings
  if (data.paymentTermDays === undefined || data.paymentTermDays === null) {
    data.paymentTermDays = settings?.invoice?.defaultPaymentTermDays ?? 30;
  }

  data.status = SO_STATUS.DRAFT;
  data.createdBy = userId;
  data.updatedBy = userId;

  const so = new SalesOrder(data);

  // Calculate totals with PPN
  const { ppnRate } = await getPpnConfig();
  so.calculateTotals(ppnRate);

  await so.save();

  return so;
};

/**
 * Update a sales order
 */
const mongoUpdateSalesOrder = async (id, data, userId) => {
  const so = await SalesOrder.findById(id);
  if (!so) {
    throw ApiError.notFound('Sales order tidak ditemukan');
  }

  if (data.fakturNumber === undefined && data.noFaktur !== undefined) {
    data.fakturNumber = data.noFaktur;
  }
  delete data.noFaktur;

  const normalizedStatus = normalizeSoStatus(so.status);
  if (so.status !== normalizedStatus) {
    so.status = normalizedStatus;
  }

  if (normalizedStatus !== SO_STATUS.DRAFT) {
    throw ApiError.badRequest('SO hanya dapat diedit saat berstatus draft');
  }

  // Validate customer if changed
  if (data.customerId) {
    const customer = await Customer.findById(data.customerId);
    if (!customer) throw ApiError.notFound('Customer tidak ditemukan');
    if (!customer.isActive) throw ApiError.badRequest('Customer tidak aktif');
  }

  // Validate products if items changed
  if (data.items) {
    data.items = normalizeSoItems(data.items);
    ensureSoItemQuantities(data.items);

    const productIds = data.items.map((item) => item.productId);
    const products = await Product.find({ _id: { $in: productIds } });
    if (products.length !== productIds.length) {
      throw ApiError.badRequest('Satu atau lebih produk tidak ditemukan');
    }
    const inactiveProduct = products.find((p) => !p.isActive);
    if (inactiveProduct) {
      throw ApiError.badRequest(`Produk "${inactiveProduct.name}" tidak aktif`);
    }
  }

  // Check duplicate SO number
  if (data.invoiceNumber) {
    const existing = await SalesOrder.findOne({
      _id: { $ne: id },
      invoiceNumber: data.invoiceNumber,
    });
    if (existing) {
      throw ApiError.conflict('Nomor SO sudah digunakan');
    }
  }

  data.updatedBy = userId;

  Object.assign(so, data);

  // Recalculate totals
  const { ppnRate } = await getPpnConfig();
  so.calculateTotals(ppnRate);

  await so.save();

  return so;
};

/**
 * Delete a sales order
 */
const mongoDeleteSalesOrder = async (id) => {
  const so = await SalesOrder.findById(id);
  if (!so) {
    throw ApiError.notFound('Sales order tidak ditemukan');
  }

  const normalizedStatus = normalizeSoStatus(so.status);
  if (so.status !== normalizedStatus) {
    so.status = normalizedStatus;
  }

  if (normalizedStatus !== SO_STATUS.DRAFT && normalizedStatus !== SO_STATUS.CANCELED) {
    throw ApiError.badRequest('SO hanya dapat dihapus saat berstatus draft atau canceled');
  }

  await so.deleteOne();
};

/**
 * Change SO status
 */
const mongoChangeStatus = async (id, newStatus, notes, userId) => {
  void notes;

  const so = await SalesOrder.findById(id);
  if (!so) {
    throw ApiError.notFound('Sales order tidak ditemukan');
  }

  const currentStatus = normalizeSoStatus(so.status);
  if (so.status !== currentStatus) {
    so.status = currentStatus;
  }

  if (currentStatus === newStatus) {
    if (so.isModified('status')) {
      await so.save();
    }
    return so;
  }

  const allowed = STATUS_TRANSITIONS[currentStatus];
  if (!allowed || !allowed.includes(newStatus)) {
    throw ApiError.badRequest(`Tidak dapat mengubah status dari '${currentStatus}' ke '${newStatus}'`);
  }

  so.status = newStatus;
  so.updatedBy = userId;

  // Set timestamp fields
  const now = new Date();

  if (newStatus === SO_STATUS.PACKED && !so.packedAt) {
    await inventoryService.createDeliveryMutations(toDeliveryLikePayload(so), userId);
    so.packedAt = now;
  }

  if (
    (newStatus === SO_STATUS.PARTIAL_DELIVERED || newStatus === SO_STATUS.DELIVERED)
    && !so.shippedAt
  ) {
    so.shippedAt = now;
  }

  if (newStatus === SO_STATUS.DELIVERED) {
    so.deliveredAt = now;
  }

  if (newStatus === SO_STATUS.COMPLETED) {
    so.completedAt = now;
  }

  if (newStatus === SO_STATUS.RETURNED) {
    so.returnedAt = now;
  }

  if (newStatus === SO_STATUS.RETURNED || newStatus === SO_STATUS.CANCELED) {
    await inventoryService.revertDeliveryMutations(toDeliveryLikePayload(so), userId);
  }

  if (newStatus === SO_STATUS.DELIVERED) {
    const deliveryPayload = toDeliveryLikePayload(so);

    try {
      await financeService.createInvoiceFromDelivery(deliveryPayload, userId);
    } catch (error) {
      logger.error(`Failed to create invoice for SO delivery: ${error.message}`);
    }

    try {
      await financeService.createCOGSJournal(deliveryPayload);
    } catch (error) {
      logger.error(`Failed to create COGS journal for SO delivery: ${error.message}`);
    }
  }

  await so.save();
  return so;
};

// ─── MySQL Helpers ───

const mapSoRow = (row, items = []) => ({
  id: row.id, _id: row.id,
  invoiceNumber: row.invoice_number,
  fakturNumber: row.faktur_number,
  status: row.status,
  customerId: row.customer_id ? { _id: row.customer_id, id: row.customer_id, name: row.customer_name, code: row.customer_code, type: row.customer_type, phone: row.customer_phone } : null,
  orderDate: row.order_date,
  deliveryDate: row.delivery_date,
  packedAt: row.packed_at, shippedAt: row.shipped_at, deliveredAt: row.delivered_at, completedAt: row.completed_at, returnedAt: row.returned_at,
  paymentTermDays: row.payment_term_days,
  shippingAddress: row.shipping_address,
  items: items.map((i) => ({
    id: i.id, _id: i.id,
    productId: { _id: i.product_id, id: i.product_id, name: i.product_name, sku: i.product_sku, golongan: i.product_golongan, satuan: i.product_satuan },
    satuan: i.satuan, quantity: i.quantity, unitPrice: Number(i.unit_price), discount: Number(i.discount), subtotal: Number(i.subtotal),
    batchNumber: i.batch_number, expiryDate: i.expiry_date, notes: i.notes,
  })),
  subtotal: Number(row.subtotal), ppnRate: Number(row.ppn_rate), ppnAmount: Number(row.ppn_amount), totalAmount: Number(row.total_amount),
  paidAmount: Number(row.paid_amount), remainingAmount: Number(row.remaining_amount),
  notes: row.notes,
  createdBy: row.created_by ? { _id: row.created_by, name: row.created_by_name } : null,
  updatedBy: row.updated_by ? { _id: row.updated_by, name: row.updated_by_name } : null,
  createdAt: row.created_at, updatedAt: row.updated_at,
});

const getSoWithItems = async (pool, id) => {
  const [rows] = await pool.query(
    `SELECT so.*, c.name as customer_name, c.code as customer_code, c.type as customer_type, c.phone as customer_phone, u1.name as created_by_name, u2.name as updated_by_name
     FROM sales_orders so LEFT JOIN customers c ON so.customer_id = c.id LEFT JOIN users u1 ON so.created_by = u1.id LEFT JOIN users u2 ON so.updated_by = u2.id
     WHERE so.id = ? LIMIT 1`, [id],
  );
  if (rows.length === 0) return null;
  const [items] = await pool.query(
    `SELECT soi.*, p.name as product_name, p.sku as product_sku, p.golongan as product_golongan, p.satuan as product_satuan
     FROM sales_order_items soi LEFT JOIN products p ON soi.product_id = p.id
     WHERE soi.sales_order_id = ? ORDER BY soi.sort_order ASC`, [id],
  );
  return mapSoRow(rows[0], items);
};

const generateInvoiceNumber = async (pool) => {
  const now = new Date();
  const ymd = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}`;
  const prefix = `SO-${ymd}-`;
  const [rows] = await pool.query('SELECT invoice_number FROM sales_orders WHERE invoice_number LIKE ? ORDER BY invoice_number DESC LIMIT 1', [`${prefix}%`]);
  const seq = rows.length > 0 ? parseInt(rows[0].invoice_number.split('-').pop(), 10) + 1 : 1;
  return `${prefix}${String(seq).padStart(4, '0')}`;
};

// ─── MySQL Implementations ───

const mysqlGetSalesOrders = async (queryParams) => {
  const pool = getMySQLPool();
  if (!pool) throw ApiError.internal('MySQL pool not initialized');
  const { page = 1, limit = 10, search, status, customerId, dateFrom, dateTo } = queryParams;
  const offset = (Number(page) - 1) * Number(limit);
  const whereClauses = []; const params = [];
  if (search) { whereClauses.push('(so.invoice_number LIKE ? OR so.faktur_number LIKE ?)'); const sl = `%${search}%`; params.push(sl, sl); }
  if (status) { const statuses = status.split(',').map((s) => s.trim()); whereClauses.push(`so.status IN (${statuses.map(() => '?').join(',')})`); params.push(...statuses); }
  if (customerId) { whereClauses.push('so.customer_id = ?'); params.push(customerId); }
  if (dateFrom) { whereClauses.push('so.order_date >= ?'); params.push(new Date(dateFrom)); }
  if (dateTo) { whereClauses.push('so.order_date <= ?'); params.push(new Date(`${dateTo}T23:59:59.999Z`)); }
  const where = whereClauses.length ? `WHERE ${whereClauses.join(' AND ')}` : '';
  const [[{ total }]] = await pool.query(`SELECT COUNT(*) as total FROM sales_orders so ${where}`, params);
  const [rows] = await pool.query(
    `SELECT so.*, c.name as customer_name, c.code as customer_code, c.type as customer_type, u1.name as created_by_name, u2.name as updated_by_name
     FROM sales_orders so LEFT JOIN customers c ON so.customer_id = c.id LEFT JOIN users u1 ON so.created_by = u1.id LEFT JOIN users u2 ON so.updated_by = u2.id
     ${where} ORDER BY so.created_at DESC LIMIT ? OFFSET ?`, [...params, Number(limit), offset],
  );
  const soIds = rows.map((r) => r.id); let itemsMap = {};
  if (soIds.length > 0) {
    const [allItems] = await pool.query(
      `SELECT soi.*, p.name as product_name, p.sku as product_sku FROM sales_order_items soi LEFT JOIN products p ON soi.product_id = p.id WHERE soi.sales_order_id IN (${soIds.map(() => '?').join(',')}) ORDER BY soi.sort_order ASC`, soIds,
    );
    for (const item of allItems) { (itemsMap[item.sales_order_id] = itemsMap[item.sales_order_id] || []).push(item); }
  }
  return { docs: rows.map((r) => mapSoRow(r, itemsMap[r.id] || [])), pagination: { page: Number(page), limit: Number(limit), total, pages: Math.ceil(total / Number(limit)) } };
};

const mysqlGetStats = async () => {
  const pool = getMySQLPool();
  if (!pool) throw ApiError.internal('MySQL pool not initialized');
  const now = new Date(); const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
  const [[totalRow], [statusRows], [totalValRow], [monthValRow], [topCustRows]] = await Promise.all([
    pool.query('SELECT COUNT(*) as total FROM sales_orders'),
    pool.query('SELECT status, COUNT(*) as count FROM sales_orders GROUP BY status'),
    pool.query('SELECT SUM(total_amount) as total FROM sales_orders WHERE status != ?', [SO_STATUS.CANCELED]),
    pool.query('SELECT SUM(total_amount) as total FROM sales_orders WHERE order_date >= ? AND status != ?', [startOfMonth, SO_STATUS.CANCELED]),
    pool.query(`SELECT so.customer_id, c.name, COUNT(*) as total_orders, SUM(so.total_amount) as total_value FROM sales_orders so JOIN customers c ON so.customer_id = c.id WHERE so.status != ? GROUP BY so.customer_id, c.name ORDER BY total_value DESC LIMIT 5`, [SO_STATUS.CANCELED]),
  ]);
  const statusMap = {}; for (const s of statusRows) statusMap[normalizeSoStatus(s.status)] = (statusMap[normalizeSoStatus(s.status)] || 0) + s.count;
  const total = Number(totalRow.total || 0); const totalValue = Number(totalValRow.total || 0); const totalValueThisMonth = Number(monthValRow.total || 0);
  const activeTotal = total - (statusMap[SO_STATUS.CANCELED] || 0);
  return { total, packed: statusMap[SO_STATUS.PACKED] || 0, delivered: statusMap[SO_STATUS.DELIVERED] || 0, partialDelivered: statusMap[SO_STATUS.PARTIAL_DELIVERED] || 0, returned: statusMap[SO_STATUS.RETURNED] || 0, canceled: statusMap[SO_STATUS.CANCELED] || 0, totalValue, totalValueThisMonth, averageOrderValue: activeTotal > 0 ? Math.round(totalValue / activeTotal) : 0, topCustomers: topCustRows };
};

const mysqlGetSalesOrderById = async (id) => {
  const pool = getMySQLPool();
  if (!pool) throw ApiError.internal('MySQL pool not initialized');
  const so = await getSoWithItems(pool, id);
  if (!so) throw ApiError.notFound('Sales order tidak ditemukan');
  return so;
};

const mysqlCreateSalesOrder = async (data, userId) => {
  const pool = getMySQLPool();
  if (!pool) throw ApiError.internal('MySQL pool not initialized');
  if (data.fakturNumber === undefined && data.noFaktur !== undefined) { data.fakturNumber = data.noFaktur; }
  delete data.noFaktur;
  data.items = normalizeSoItems(data.items);
  ensureSoItemQuantities(data.items);
  const [[customer]] = await pool.query('SELECT id, name, is_active, address_street, address_city, address_province FROM customers WHERE id = ? LIMIT 1', [data.customerId]);
  if (!customer) throw ApiError.notFound('Customer tidak ditemukan');
  if (!customer.is_active) throw ApiError.badRequest('Customer tidak aktif');
  const productIds = data.items.map((item) => item.productId);
  const [products] = await pool.query(`SELECT id, name, is_active FROM products WHERE id IN (${productIds.map(() => '?').join(',')})`, productIds);
  if (products.length !== productIds.length) throw ApiError.badRequest('Satu atau lebih produk tidak ditemukan');
  const ip = products.find((p) => !p.is_active); if (ip) throw ApiError.badRequest(`Produk "${ip.name}" tidak aktif`);
  const id = new mongoose.Types.ObjectId().toString();
  const invoiceNumber = data.invoiceNumber || await generateInvoiceNumber(pool);
  if (!data.shippingAddress) { const parts = [customer.address_street, customer.address_city, customer.address_province].filter(Boolean); data.shippingAddress = parts.join(', ') || null; }
  const ppnRate = 0; // simplified - real logic reads from AppSetting
  const subtotal = data.items.reduce((sum, i) => sum + (i.subtotal || i.quantity * i.unitPrice * (1 - (i.discount || 0) / 100)), 0);
  const ppnAmount = Math.round(subtotal * ppnRate / 100);
  const totalAmount = subtotal + ppnAmount;
  await pool.query(
    `INSERT INTO sales_orders (id, invoice_number, faktur_number, status, customer_id, order_date, delivery_date, payment_term_days, shipping_address, subtotal, ppn_rate, ppn_amount, total_amount, paid_amount, remaining_amount, notes, created_by, updated_by, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,0,?,?,?,?,NOW(),NOW())`,
    [id, invoiceNumber, data.fakturNumber || null, SO_STATUS.DRAFT, data.customerId, data.orderDate || new Date(), data.deliveryDate || null, data.paymentTermDays ?? 30, data.shippingAddress || null, subtotal, ppnRate, ppnAmount, totalAmount, totalAmount, data.notes || null, userId, userId],
  );
  for (let i = 0; i < data.items.length; i++) {
    const item = data.items[i]; const itemId = new mongoose.Types.ObjectId().toString();
    const itemSubtotal = item.subtotal || item.quantity * item.unitPrice * (1 - (item.discount || 0) / 100);
    // eslint-disable-next-line no-await-in-loop
    await pool.query('INSERT INTO sales_order_items (id, sales_order_id, product_id, satuan, quantity, unit_price, discount, subtotal, batch_number, expiry_date, notes, sort_order) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)', [itemId, id, item.productId, item.satuan, item.quantity, item.unitPrice, item.discount || 0, itemSubtotal, item.batchNumber || null, item.expiryDate || null, item.notes || null, i]);
  }
  return mysqlGetSalesOrderById(id);
};

const mysqlUpdateSalesOrder = async (id, data, userId) => {
  const pool = getMySQLPool();
  if (!pool) throw ApiError.internal('MySQL pool not initialized');
  const [[existing]] = await pool.query('SELECT id, status FROM sales_orders WHERE id = ? LIMIT 1', [id]);
  if (!existing) throw ApiError.notFound('Sales order tidak ditemukan');
  if (normalizeSoStatus(existing.status) !== SO_STATUS.DRAFT) throw ApiError.badRequest('SO hanya dapat diedit saat berstatus draft');
  if (data.fakturNumber === undefined && data.noFaktur !== undefined) { data.fakturNumber = data.noFaktur; }
  delete data.noFaktur;
  const fieldMap = { fakturNumber: 'faktur_number', orderDate: 'order_date', deliveryDate: 'delivery_date', paymentTermDays: 'payment_term_days', shippingAddress: 'shipping_address', notes: 'notes' };
  if (data.customerId) fieldMap.customerId = 'customer_id';
  const setClauses = ['updated_by = ?', 'updated_at = NOW()']; const values = [userId];
  for (const [key, col] of Object.entries(fieldMap)) { if (data[key] !== undefined) { setClauses.push(`${col} = ?`); values.push(data[key]); } }
  values.push(id);
  await pool.query(`UPDATE sales_orders SET ${setClauses.join(', ')} WHERE id = ?`, values);
  if (data.items) {
    data.items = normalizeSoItems(data.items); ensureSoItemQuantities(data.items);
    await pool.query('DELETE FROM sales_order_items WHERE sales_order_id = ?', [id]);
    for (let i = 0; i < data.items.length; i++) {
      const item = data.items[i]; const itemId = new mongoose.Types.ObjectId().toString();
      // eslint-disable-next-line no-await-in-loop
      await pool.query('INSERT INTO sales_order_items (id, sales_order_id, product_id, satuan, quantity, unit_price, discount, subtotal, batch_number, expiry_date, notes, sort_order) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)', [itemId, id, item.productId, item.satuan, item.quantity, item.unitPrice, item.discount || 0, item.subtotal || item.quantity * item.unitPrice, item.batchNumber || null, item.expiryDate || null, item.notes || null, i]);
    }
  }
  return mysqlGetSalesOrderById(id);
};

const mysqlDeleteSalesOrder = async (id) => {
  const pool = getMySQLPool();
  if (!pool) throw ApiError.internal('MySQL pool not initialized');
  const [[existing]] = await pool.query('SELECT id, status FROM sales_orders WHERE id = ? LIMIT 1', [id]);
  if (!existing) throw ApiError.notFound('Sales order tidak ditemukan');
  const normalizedStatus = normalizeSoStatus(existing.status);
  if (normalizedStatus !== SO_STATUS.DRAFT && normalizedStatus !== SO_STATUS.CANCELED) throw ApiError.badRequest('SO hanya dapat dihapus saat berstatus draft atau canceled');
  await pool.query('DELETE FROM sales_order_items WHERE sales_order_id = ?', [id]);
  await pool.query('DELETE FROM sales_orders WHERE id = ?', [id]);
};

const mysqlChangeStatus = async (id, newStatus, notes, userId) => {
  const pool = getMySQLPool();
  if (!pool) throw ApiError.internal('MySQL pool not initialized');
  const [[existing]] = await pool.query('SELECT id, status, customer_id FROM sales_orders WHERE id = ? LIMIT 1', [id]);
  if (!existing) throw ApiError.notFound('Sales order tidak ditemukan');
  const currentStatus = normalizeSoStatus(existing.status);
  if (currentStatus === newStatus) return mysqlGetSalesOrderById(id);
  const allowed = STATUS_TRANSITIONS[currentStatus];
  if (!allowed || !allowed.includes(newStatus)) throw ApiError.badRequest(`Tidak dapat mengubah status dari '${currentStatus}' ke '${newStatus}'`);
  const setClauses = ['status = ?', 'updated_by = ?', 'updated_at = NOW()']; const values = [newStatus, userId];
  const now = new Date();
  if (newStatus === SO_STATUS.PACKED) { setClauses.push('packed_at = ?'); values.push(now); }
  if (newStatus === SO_STATUS.PARTIAL_DELIVERED || newStatus === SO_STATUS.DELIVERED) { setClauses.push('shipped_at = ?'); values.push(now); }
  if (newStatus === SO_STATUS.DELIVERED) { setClauses.push('delivered_at = ?'); values.push(now); }
  if (newStatus === SO_STATUS.COMPLETED) { setClauses.push('completed_at = ?'); values.push(now); }
  if (newStatus === SO_STATUS.RETURNED) { setClauses.push('returned_at = ?'); values.push(now); }
  values.push(id);
  await pool.query(`UPDATE sales_orders SET ${setClauses.join(', ')} WHERE id = ?`, values);

  // Fetch full SO for side effects
  const so = await getSoWithItems(pool, id);
  const deliveryPayload = {
    _id: so.id,
    salesOrderId: so.id,
    customerId: so.customerId?._id || so.customerId,
    deliveryNumber: so.invoiceNumber,
    deliveredAt: so.deliveredAt,
    updatedBy: userId,
    items: (so.items || []).map((item) => ({
      productId: item.productId?._id || item.productId,
      satuan: item.satuan,
      quantityOrdered: Number(item.quantity || 0),
      quantityShipped: Number(item.quantity || 0),
      batchNumber: item.batchNumber || null,
      expiryDate: item.expiryDate || null,
    })),
  };

  // Side effect: create stock OUT mutations on packed
  if (newStatus === SO_STATUS.PACKED) {
    await inventoryService.createDeliveryMutations(deliveryPayload, userId);
  }

  // Side effect: revert stock mutations on returned/canceled
  if (newStatus === SO_STATUS.RETURNED || newStatus === SO_STATUS.CANCELED) {
    await inventoryService.revertDeliveryMutations(deliveryPayload, userId);
  }

  // Side effect: create invoice & COGS journal on delivered (non-blocking)
  if (newStatus === SO_STATUS.DELIVERED) {
    try {
      await financeService.createInvoiceFromDelivery(deliveryPayload, userId);
    } catch (err) { logger.error(`Failed to create invoice for MySQL SO delivery: ${err.message}`); }
    try {
      await financeService.createCOGSJournal(deliveryPayload);
    } catch (err) { logger.error(`Failed to create COGS journal for MySQL SO delivery: ${err.message}`); }
  }

  return mysqlGetSalesOrderById(id);
};

// ─── Exported Functions with Provider Branching ───

const getSalesOrders = (q) => config.dbProvider === 'mysql' ? mysqlGetSalesOrders(q) : mongoGetSalesOrders(q);
const getStats = () => config.dbProvider === 'mysql' ? mysqlGetStats() : mongoGetStats();
const getSalesOrderById = (id) => config.dbProvider === 'mysql' ? mysqlGetSalesOrderById(id) : mongoGetSalesOrderById(id);
const createSalesOrder = (data, userId) => config.dbProvider === 'mysql' ? mysqlCreateSalesOrder(data, userId) : mongoCreateSalesOrder(data, userId);
const updateSalesOrder = (id, data, userId) => config.dbProvider === 'mysql' ? mysqlUpdateSalesOrder(id, data, userId) : mongoUpdateSalesOrder(id, data, userId);
const deleteSalesOrder = (id) => config.dbProvider === 'mysql' ? mysqlDeleteSalesOrder(id) : mongoDeleteSalesOrder(id);
const changeStatus = (id, newStatus, notes, userId) => config.dbProvider === 'mysql' ? mysqlChangeStatus(id, newStatus, notes, userId) : mongoChangeStatus(id, newStatus, notes, userId);

module.exports = { getSalesOrders, getStats, getSalesOrderById, createSalesOrder, updateSalesOrder, deleteSalesOrder, changeStatus };
